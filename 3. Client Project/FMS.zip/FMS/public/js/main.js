$(document).ready(function(){
    $('.delete-equip').on('click', function(e) {
        $target = $(e.target);
        var id = $target.attr('data-id');
        id = id.slice(1, -1);
        console.log("ID : : " + id);
        $.ajax({
            type:'DELETE',
            url: '/equipt/'+id,
            success: function() {
                alert('Deleting Equipment');
                window.location.href='/equipt';
            },
            error: function(err) {
                console.log(err);
            }
        });
    });
});