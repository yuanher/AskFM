module.exports =
{
    dbUrl:'mongodb+srv://fms_user:Passw0rd@clust-wchpu.gcp.mongodb.net/fms',
    secret:''
}