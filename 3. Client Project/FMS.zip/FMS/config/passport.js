const LocalStrategy = require('passport-local').Strategy;
const Usr  = require('../models/usr');
var config = require('./database');
var bcrypt = require('bcrypt');

    module.exports = function(passport) {
        //Local Strategy
        passport.use(new LocalStrategy(function(username, password, done) {
            let query = {username:username};
            //Match Username

            Usr.findOne({username: username})
                .then((user) => {
                    console.log("Server: Found User: " + JSON.stringify(user));
                    console.log(user);
                    if(user != null) {
                        console.log("Server: Comparing passwords: "  + password +  ":" + user.password);
                        bcrypt.compare(password, user.password, function(err, rslt) {
                            console.log("Resut: " + rslt);
                            if(rslt == true) {
                                return done(null, user);
                            } else {
                                return done(null, false, {message:"Wrong Password"});
                            }
                        });
                    } else {
                        return done(null, false, {message:"No User Found"});			
                    }
                })
                .catch((err) => {
                    console.log(err);
                    return new Promise((resolve, reject) => {
                        reject(new Error('Fail!'))
                    });
                    //return Promise.reject(err);
                });
        }));
        passport.serializeUser(function(user, done) {
            done(null, user.id);
        });

        passport.deserializeUser(function(id, done) {
            Usr.findById(id, function(err, user) {
            done(err, user);
        });
    });
};
