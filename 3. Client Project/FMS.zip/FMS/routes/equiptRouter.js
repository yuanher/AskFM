const express  = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const Equipment = require('../models/equipment');

const equiptRouter = express.Router();

equiptRouter.use(bodyParser.json());

const { check, validationResult } = require('express-validator/check');

equiptRouter.get('/add', ensureAuthenticated, function(req, res, next) {
	res.render('add', {
		title:'Add Equipment'
	  });
});

equiptRouter.post('/add', ensureAuthenticated, function(req, res, next) {
	// Get Errors
	req.checkBody('name','Name Cannot be Empty').notEmpty();
	req.checkBody('location','Location Cannot be Empty').notEmpty();
	req.checkBody('status','Status Cannot be Empty').notEmpty();
	req.checkBody('command','Command Cannot be Empty').notEmpty();
	req.checkBody('temperature','Temperature Cannot be Empty').notEmpty();
	req.checkBody('humidity','Humidity Cannot be Empty').notEmpty();
	req.checkBody('schedStartTime','Scheduled Start Time Cannot be Empty').notEmpty();
	req.checkBody('schedStopTime','Scheduled Stop Time Cannot be Empty').notEmpty();
	req.checkBody('schedFrequency','Scheduled Frequency Cannot be Empty').notEmpty();
	var errors = req.validationErrors(true);
	if(errors) {
		var err = JSON.parse(JSON.stringify(errors))
		for (x in err) {
			req.flash('danger', err[x].msg);
		};

		res.render('add', {
			title: "Add Equipment"
		});
	} else {
		let equip = new Equipment();
		equip.name = req.body.name;
		equip.location = req.body.location;
		equip.status = req.body.status;
		equip.command = req.body.command;
		equip.temperature = req.body.temperature;
		equip.humidity = req.body.humidity;
		equip.Alarm = req.body.Alarm;
		equip.AlarmDesc = req.body.AlarmDesc;
		equip.schedule = [{StartTime:req.body.schedStartTime,
											 StopTime:req.body.schedStopTime,
											 Frequency:req.body.schedFrequency}]
		console.log(JSON.stringify(equip));
		equip.save(function(err, rslt) {
			if(err) {
				console.log(err) 
				return;
			} else { 
				req.flash('success','Equipment Added');
				res.redirect('/equipt');
			}
		});
	}
	
});

equiptRouter.get('/:id', ensureAuthenticated, function(req, res, next) {
	Equipment.findById(req.params.id, function(err, equip) {
		console.log(equip);
		res.render('equipt', {
			equipment:equip
		});
	});
});

equiptRouter.delete('/:id', ensureAuthenticated, function(req, res, next) {
	Equipment.findById(req.params.id, function(err, equip) {
		if(err) {
		  console.log(err);
		} else {
			Equipment.findOneAndRemove({"_id":req.params.id}, function(err) {
				if(err) {
					console.log(err);
				} else {
					req.flash('success','Equipment Removed');
					res.render('equipt', {
						equipment:equip
					});
				};
			});
		}
	});
});

equiptRouter.get('/edit/:id', ensureAuthenticated, function(req, res, next) {
	Equipment.findById(req.params.id, function(err, equip) {
		res.render('edit', {
			title: 'Edit Equipment',
			equipment:equip
		});
	});
});

equiptRouter.post('/edit/:id', ensureAuthenticated, function(req, res, next) {
	let equip ={};
	equip.name = req.body.name;
	equip.location = req.body.location;
	equip.status = req.body.status;
	equip.command = req.body.command;
	equip.temperature = req.body.temperature;
	equip.humidity = req.body.humidity;
	equip.Alarm = req.body.Alarm;
	equip.AlarmDesc = req.body.AlarmDesc;
	equip.schedule = [{StartTime: req.body.schedStartTime,
										 StopTime: req.body.schedStopTime,
										 Frequency: req.body.schedFrequency}];
	let query = {_id:req.params.id}
  
	Equipment.findOneAndUpdate(query, equip, function(err, rslt) {
		//console.log(JSON.stringify(equip));
		console.log(rslt);
	  if(err) {
		console.log(err) 
		  return;
	  } else { 
			req.flash('success','Equipment Updated');
			res.redirect('/equipt');
	  }
	});
});

equiptRouter.get('/', ensureAuthenticated, function(req, res, next) {
	  Equipment.find({}, function(err, equipment) {
		if(err) {
		  console.log(err);
		} else {
		  res.render('index', { 
			title: 'Facility Management System',
			equipment: equipment
		 });
		}
	  });
});

function ensureAuthenticated(req, res, next) {
	if(req.isAuthenticated()) {
		return next();
	} else {
		req.flash('danger', 'Please login');
		res.redirect('/users/login');
	}
};

module.exports = equiptRouter;