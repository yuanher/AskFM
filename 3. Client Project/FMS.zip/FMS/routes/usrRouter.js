const express  = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
var passport = require('passport'); 

const Usr  = require('../models/usr');

const usrRouter = express.Router();

usrRouter.use(bodyParser.json());

const { check, validationResult } = require('express-validator/check');

usrRouter.route('/register')
.get( (req, res, next) => {
	res.render('register', {
		title:'User Registration'
	  });
})

.post( (req, res, next) => {
	// Get Errors
	req.checkBody('name','Name Cannot be Empty').notEmpty();
	req.checkBody('email','Email is not valid').isEmail();
	req.checkBody('username','User Name Cannot be Empty').notEmpty();
	req.checkBody('password','Password Cannot be Empty').notEmpty();
	req.checkBody('password2','Passwords do not match').equals(req.body.password);
	var errors = req.validationErrors(true);
	if(errors) {
		var err = JSON.parse(JSON.stringify(errors))
		for (x in err) {
			req.flash('danger', err[x].msg);
		};

		res.render('register', {
			title: "User Registration"
		});
	} else {
		console.log("Registering new user");
		let usr = new Usr();
		usr.name = req.body.name;
		usr.email = req.body.email;
		usr.username = req.body.username;
		usr.password = req.body.password;
		console.log(JSON.stringify(usr));

		bcrypt.hash(usr.password, 10)
		.then((hash) => {
			usr.password = hash;
			Usr.create(usr);
		}) 
 		.then((user) => {
			req.flash('success','You are now registered and can login');
			res.redirect('/users/login');
		}, (err) => next(err))
		.catch((err) => next(err));
	}
});

usrRouter.route('/login')
.get( (req, res, next) => {
	res.render('login', {
		title:'User Login'
	  });
})

.post( (req, res, next) => {
	passport.authenticate('local', {
		successRedirect:'/equipt',
		failureRedirect:'/users/login',
		failureFlash: true
	})(req, res, next);
});

usrRouter.route('/logout')
.get( (req, res, next) => {
	req.logout();
	req.flash('success', 'You are logged out');
	res.redirect('/users/login');
})

module.exports = usrRouter;