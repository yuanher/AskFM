const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const scheduleSchema = new Schema({
	StartTime: {
		type: String,
		required: true
	},
	StopTime: {
		type: String,
		required: true
	},
	Frequency: {
		type: String,
		required: true
	}	
},{
		timestamps: true
});
	
const equipmentSchema = new Schema({
	name: {
		type: String,
		required: true,
		unique: true
	},	
	location: {
		type: String,
		required: true
	},
	temperature: {
		type: Number,
		required: true,
		min:20,
		max:50
	},
	humidity: {
		type: Number,
		required: true,
		min:0,
		max:100
	},		
	status: {
		type: String,
		default: ''
	},	
	command: {
		type: String,
		default: ''
	},
	Alarm: {
		type: Boolean,
		default: false
	},
	AlarmDesc: {
		type: String,
		default: ''
	},
	schedule: [scheduleSchema]
},{ 
		timestamps: true
});

var Equipment = mongoose.model("Equipment", equipmentSchema);

module.exports = Equipment;


