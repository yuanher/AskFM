import { Component, NgZone } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Platform } from 'ionic-angular';
declare var ApiAIPromises: any;
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  messages: any[] = [];
  text: string = "";

  constructor(public navCtrl: NavController, public ngZone: NgZone,public platform: Platform) {
    platform.ready().then(() => {
      ApiAIPromises.init({
        clientAccessToken: "3212383a1c124a03b268234194193273" 
      }).then(result => console.log(result));
    });
    this.messages.push({
      text: "Hi, how can I help you?",
      sender: "api"
    })
  }
  sendText(){
    let message = this.text;
    
        this.messages.push({
          text: message,
          sender: 'me'
        }); 
    this.text = "";
    ApiAIPromises.requestText({
      query: message
    })
    .then((response) => {console.log(response.result.fulfillment.speech);    
      this.ngZone.run(()=>{
        this.messages.push({
             text: response.result.fulfillment.speech,
            sender: "api"
        });
   
      })
    })
  }
}
