//
//  AIVoiceFileRequest_Private.h
//  ApiAI
//
//  Created by Kuragin Dmitriy on 30/07/15.
//  Copyright © 2015 Kuragin Dmitriy. All rights reserved.
//

#import "AIVoiceFileRequest.h"

@interface AIVoiceFileRequest ()

@property(nonatomic, strong) NSInputStream *inputStream;

@end
