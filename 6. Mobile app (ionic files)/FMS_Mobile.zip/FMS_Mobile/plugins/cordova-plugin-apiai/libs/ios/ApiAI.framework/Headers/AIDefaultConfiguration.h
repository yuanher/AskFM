//
//  AIDefaultConfiguration.h
//  ApiAI
//
//  Created by Kuragin Dmitriy on 14/11/14.
//  Copyright (c) 2014 Kuragin Dmitriy. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "AIConfiguration.h"

@interface AIDefaultConfiguration : NSObject <AIConfiguration>

@end
