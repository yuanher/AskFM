//
//  AIUserEntity+Private.h
//  ApiAI
//
//  Created by Kuragin Dmitriy on 11/01/16.
//  Copyright © 2016 Kuragin Dmitriy. All rights reserved.
//

#import "AIUserEntity.h"

@interface AIUserEntity ()

@end
