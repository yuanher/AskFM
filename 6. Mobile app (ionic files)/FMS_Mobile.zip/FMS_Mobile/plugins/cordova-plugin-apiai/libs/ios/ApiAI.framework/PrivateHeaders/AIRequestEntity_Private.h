//
//  AIRequestEntity_Representation.h
//  Pods
//
//  Created by Kuragin Dmitriy on 22/05/15.
//
//

#import "AIRequestEntity.h"

@interface AIRequestEntity ()

@property(nonatomic, copy, readonly, AI_NONNULL) NSDictionary *dictionaryPresentation;

@end
